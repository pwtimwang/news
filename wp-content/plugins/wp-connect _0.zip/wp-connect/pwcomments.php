<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0649)http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&domain=www.pingwest.com&postid=5118&title=%E2%80%9C%E6%B5%81%E6%B0%93%E5%8A%A9%E6%89%8B%E2%80%9D%E5%92%8C%E5%AE%83%E7%9A%84%E6%9C%8B%E5%8F%8B%E4%BB%AC&from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&image=http%3A%2F%2Fwww.pingwest.com%2Fwp-content%2Fuploads%2F2013%2F01%2F%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2013-01-19-%E4%B8%8A%E5%8D%888.21.22.png&exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49 -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>评论</title>
<link href="./pwcomments_files/static.css" rel="stylesheet" type="text/css">

<link href="./pwcomments_files/model3.css" rel="stylesheet" type="text/css">


<style type="text/css">

</style>



<script src="./pwcomments_files/comment_a.js" type="text/javascript"></script>
<script type="text/javascript">
_domain = 'www.pingwest.com';
var _denglu_isLogin = true;
var _denglu_image_url = 'http://www.pingwest.com/wp-content/uploads/2013/01/屏幕快照-2013-01-19-上午8.21.22.png';
var _denglu_video_url = '';
var _denglu_postfromurl = '';

var commentCookieName = 'comment-20592denRbLvRNV4o0NRZSqfVtBsXA-157237';
var shareCookieName = 'share-20592denRbLvRNV4o0NRZSqfVtBsXA-157237';
var logininfo = "来说几句吧...";
var _denglu_strange_name_info = "匿名";
var _denglu_strange_email_info = "";
var _denglu_strange_url_info = "http://";
var _denglu_is_elle = false;
var _denglu_is_elle_cad = false;
var _denglu_top_textarea = true;
var _denglu_cstrangeemail = true;
var _denglu_subjectid = 157237;
var _denglu_templateid = 3;
$(function () {
	

	$("#sortAllLink").click(function (e) {//排序
    	$("#sortTypeMenu").toggle();
		resizeIframeComment(document.body.scrollHeight < 415 ? document.body.scrollHeight - 415 : 0);
		stopBubble(e);
	});
	$(".dl_sort_select").change(function() {
		location.href = $(this).val();
	});
	$("#idenglu_emotion").children("li").click(function(e) {
		emotionClick(e, $(this).children("img"));
	}).end()
	.find(".dl_face_body").find("#idenglu_emotion_tab_qq").children("a").click(function(e) {
		emotionClick(e, this);
	}).end().end()
	.find("#idenglu_emotion_tab_ali,#idenglu_emotion_tab_lang").children("a").click(function(e) {
		emotionClick(e, this, 2);
	});
	$("#idenglu_synchro, .dl_face_menu").click(function(e) {
		stopBubble(e);
	});
  	$(document.body).click( function() {
		$("#idenglu_synchro_1:visible").hide();
		$("#idenglu_synchro_2:visible").hide();
		$("#idenglu_synchro_3:visible").hide();
		if ($("#idenglu_emotion_1:visible").length || $("#idenglu_emotion_3:visible").length) {
			var type = $("#idenglu_emotion").attr("emotion_type");
			if (type && type != 2) {
				resizeIframeComment();
			}
		}
		$("#idenglu_emotion_1:visible").hide();
		$("#idenglu_emotion_2:visible").hide();
		$("#idenglu_emotion_3:visible").hide();
 		$("#sortTypeMenu:visible").hide();
	});

  	// 评论框
  	bindInfo($("#idenglu_comment_content"), logininfo, function() {$("#idenglu_comment_succeed").hide();});
  	if ($.trim($("#idenglu_name2").val())) {
  		_denglu_strange_name_info = $("#idenglu_name2").val();
  	}
  	bindInfo($("#idenglu_name2"), _denglu_strange_name_info);
  	bindInfo($("#idenglu_name"), _denglu_strange_name_info);
  	bindInfo($("#idenglu_email2"), _denglu_strange_email_info);
  	bindInfo($("#idenglu_email"), _denglu_strange_email_info);
  	bindInfo($("#idenglu_homepage2"), _denglu_strange_url_info);
  	bindInfo($("#idenglu_homepage"), _denglu_strange_url_info);
  	$("#idenglu_reply_content").focus(function() {$("#idenglu_reply_succeed").hide();})

  	// 一键分享的内容字数
  	$("#idenglu_share_content").keyup(function(evt){
		$("#idenglu_share_content_count").html(count($(this).val())/2);
	});
  	$("#idenglu_comment_content").keyup(function(evt){
		$("#idenglu_comment_content_count").html("已输入" + (count($(this).val())/2) + "个字");
	});
  	$("#idenglu_reply_content").keyup(function(evt){
		$("#idenglu_reply_content_count").html("已输入" + (count($(this).val())/2) + "个字");
	});
});

function emotionClick(e, node, etype) {
	var $idenlgu_face = $("#idenglu_emotion");
	var type = $idenlgu_face.attr("emotion_type");
	if (!type) {
		type = 1;
	}
	var left = etype == 2 ? "[" : "(";
	var right = etype == 2 ? "]" : ")";
	switch (type) {
	case 1:
	case "1":
		if ($("#idenglu_comment_content").val() == logininfo) {
			$("#idenglu_comment_content").val("");
		}
		$("#idenglu_comment_content").val($("#idenglu_comment_content").val() + left + $(node).attr("title") + right).keyup();
		break;
	case 2:
	case "2":
		$("#idenglu_share_content").val($("#idenglu_share_content").val() + left + $(node).attr("title") + right).keyup();
		break;
	case 3:
	case "3":
		$("#idenglu_reply_content").val($("#idenglu_reply_content").val() + left + $(node).attr("title") + right).keyup();
		break;
	}
	$("#idenglu_emotion_" + type).hide();
	resizeIframeComment();
	stopBubble(e);
}

function bindInfo(node, info, focusFunction) {
	$(node).focus(function() {
	  	if ($(this).val() == info && info != _denglu_strange_url_info) {
			$(this).val("");
	  	}
	  	if ($.isFunction(focusFunction)) {
	  		focusFunction();
		}
  	})
  	.blur(function() {
		if (!$(this).val()) {
			$(this).val(info);
		}
  	}).val(info);
}

function resizeIframeComment(height) {
	if (!height) {
		height = 0;
	}
	parent.socket.postMessage(parseInt($(".dengluComments").height() - height));
}
function gotoTop(flag) {
	parent.socket.postMessage(flag);
}
function exitAction() {
	parent.socket.postMessage("exit");
}
</script>

<script type="text/javascript" src="./pwcomments_files/model3.js"></script>

</head>
<body>
<div class="dengluComments">
<!--灯鹭社会化评论 begin-->
<div class="dl_comment">
	<!--头部信息及功能 begin-->
	<div class="dl_head layout">
		<div class="dl_head_tlt">PingWest</div>
		<ul class="dl_head_link layout">
			<li class="dl_head_community"><a onclick="javascript:_CAC.intoPanel(36994);" href="javascript:;" title="社区中心"><span>社区中心</span></a></li>
			<li class="dl_head_share"><a onclick="javascript:_CAC.showShare();" href="javascript:;" title="分享文章"><span>分享文章</span></a></li>
			<li class="dl_head_bind"><a href="javascript:;" onclick="_CAC.intoBind()" title="绑定设置"><span>绑定设置</span></a></li>
		</ul>
	</div>
	<!--头部信息及功能 end-->
	<!--评论框部分 begin-->
	<div class="dl_publish">
		<div class="dl_publish_login">
			<div id="idenglu_userinfo" class="dl_publish_success">
				<b id="idenglu_userinfo_name">xyz6789</b>&nbsp;&nbsp;您好！<a onclick="javascript:_CAC.exit(36994);" href="javascript:;">退出</a>
			</div>
		</div>
		<div class="dl_publish_textarea">
			<div class="dl_avatar"><img src="./pwcomments_files/1"></div>
			<div class="dl_textarea">
			<div class="dl_textarea_jiao"></div>
				<div class="dl_textarea_input"><textarea id="idenglu_comment_content"></textarea></div>
				<div class="dl_textarea_tool layout">
					<ul class="dl_tool_btn layout">
						<li class="dl_tool_face">
							<a href="javascript:;" onclick="javascript:_CAC.showEmotionModel(event, 1);">表情</a>
							<!--表情弹出层 begin-->
							<div id="idenglu_emotion_1" style="display:none;">
							</div>
							<!--表情弹出层 end-->
						</li>
						<!--同步部分 begin-->
						<li id="idenglu_synchro_list_1" class="dl_tool_feed">
							<ul class="dl_feed_layout layout">
	<li class="dl_feed_text">同步到：</li>
	<li onclick="javascript:_CAC.clickSynchro(this);" mid="3" ck="0" class="icon_3"></li>
</ul>

						</li>
						<!--同步部分 end-->
					</ul>
					<div class="dl_tool_submit">
						<a class="dl_submit_btn" href="javascript:;" onclick="javascript:_CAC.addComment(36994, 157237, 3);">发布评论</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--评论框部分 end-->
	<!--评论列表信息部分 包括信息、排序、分页等 begin-->
	<div class="dl_infor layout">
		<div class="dl_infor_message layout">
			<div class="dl_message">已有<em>28</em>条评论,共<em>18</em>人参与</div>
			<div class="dl_sort">
				<select class="dl_sort_select">
	<option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=0">按时间排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=1" selected="selected">按时间倒序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=2">按平台排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=3">按好评度排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=4">按回复数排序
</option></select>

			</div>
		</div>
		<div class="dl_infor_page layout"></div>

	</div>
	<!--评论列表信息部分 包括信息、排序、分页等 end-->
	<!--评论列表 begin-->
	<div id="idenglu_comments" class="dl_list">
	<div id="c1507464" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://aass1.cc/">
				<img src="./pwcomments_files/8a8524f436793299590f4f278ae4ac5e">
			</a>
			
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://aass1.cc/">匿名</a>
					
					<span class="dl_name_from">来自广东省的网友</span>
					<span class="dl_name_time" title="发表于2013-01-23 12:42:06">4小时前</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>如果把快用叫流氓，那所有的越狱用户的都得叫强 奸 犯了？是不是越狱开发者都得下地狱？不要把你的APP利润低和不付费下载做挂钩，搞清楚现在是什么时代了？举几个简单例子，小怪吃糖糖靠的是应用下载付费活到现在吗？pc平台的客户端游戏都是靠直接购买客户端的付费用户活到现在吗？国内哪个网络游戏需要靠直接贩卖客户端来盈利？难道那些付费下载的应用里都没有广告了？？可笑至极
还有不要说什么5000块的手机200块的应用，你买pc是为了买微软的操作系统？肯定会有人跳出来说，买苹果就是为了用上面的app，好啊，那我请问，如果没有越狱，没有类似快用这些软件，苹果还会有这么多人买吗？？？？？还会有app这么大的市场吗？？？天上不会掉馅饼，会赚钱的也从来没饿着过。搞搞清楚现在用户买的都是服务，而不是你的下载付费，带着老旧观念活，总归最后就是被淘汰的下场。你选择了让下载付费占满你的所有盈利通道，那你注定就是失败，道理就是这么简单！</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-23 12:42:06">4小时前</li>
					<li class="dl_control_from dl_from_address">来自广东省的网友</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1507464">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1507464, 36994, 1507464, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1507464, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<div class="dl_reply_control">
		<div id="idenglu_showRepliesJS_1507464" class="dl_reply_down" style="display:none">
			<a href="javascript:;" onclick="javascript:_CAC.showReplies(1507464);"><span></span>展开回复</a>
		</div>
		<div id="idenglu_hideRepliesJS_1507464" class="dl_reply_up">
			<a href="javascript:;" onclick="javascript:_CAC.hideReplies(1507464);"><span></span>收起回复</a>
		</div>
	</div>
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1507464" class="dl_reply">
	<div id="c1507730" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/e67202a15ee6a161f3b78f9c76195133">
			</a>
                        
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">匿名</a>
					
					<span class="dl_name_from dl_from_address">来自福建省福州市的网友</span>
					<span class="dl_name_time" title="发表于2013-01-23 16:18:12">1小时前</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>完全没有知识产权保护概念的人智商和逻辑真是让人着急，我也越狱，但是我只是为了使用一些app store和手机本身无法提供的功能，比如搜狗输入法，付费软件照买谢谢</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-23 16:18:12">1小时前</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1507730">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1507464, 36994, 1507730, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1507730, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1507732" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/e67202a15ee6a161f3b78f9c76195133">
			</a>
                        
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">匿名</a>
					
					<span class="dl_name_from dl_from_address">来自福建省福州市的网友</span>
					<span class="dl_name_time" title="发表于2013-01-23 16:20:32">1小时前</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>再加一句，请你看看你自己说的逻辑，你评论说如果没有越狱，还会有app这么大的市场吗？请问app市场开发是为了被越狱吗，呵呵呵呵呵地笑了</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-23 16:20:32">1小时前</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1507732">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1507464, 36994, 1507732, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1507732, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
	<div id="c1507463" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://aass1.cc/">
				<img src="./pwcomments_files/8a8524f436793299590f4f278ae4ac5e">
			</a>
			
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://aass1.cc/">匿名</a>
					
					<span class="dl_name_from">来自广东省的网友</span>
					<span class="dl_name_time" title="发表于2013-01-23 12:41:04">4小时前</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>引用原文：用户安装后出现App打不开、崩溃等状况，你的产品还很可能要为此承担骂名。
我用快用用到现在，已经几个月之久，为什么从未出现过你说的状况？
引用原文：1. 无法再与iTunes的库进行同步其他应用，一旦同步，通过这些工具安装的应用将全部消失；
你知道所有的越狱用户都不会去同步吗？因为那样一样会丢失应用，还有我认识的所有的用苹果的人都不会去用itunes去下载软件，知道为什么？因为他不好用。
引用：2. 通过这些工具安装的应用无法直接更新，而需要等待“快用”的服务器更新后才行。
我认为只有智商存在问题的人才会去appstore直接更新，因为那慢的还不如不更新。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-23 12:41:04">4小时前</li>
					<li class="dl_control_from dl_from_address">来自广东省的网友</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1507463">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1507463, 36994, 1507463, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1507463, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1507463" class="dl_reply">
</div>
	<div id="c1503622" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/100">
			</a>
			<div class="dl_post_avatar_icon icon_13"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">阿涛</a>
					<span class="dl_name_icon icon_13"></span>
					<span class="dl_name_from">来自QQ</span>
					<span class="dl_name_time" title="发表于2013-01-20 13:28:25">1月20日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>在中国是没有底线的</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-20 13:28:25">1月20日</li>
					<li class="dl_control_from dl_from_media">来自QQ</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1503622">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1503622, 36994, 1503622, &#39;阿涛&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1503622, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1503622" class="dl_reply">
</div>
	<div id="c1502546" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/a0698ae3df16c69ccf51357d85d5c810">
			</a>
			
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">faceme</a>
					
					<span class="dl_name_from">来自北京市的网友</span>
					<span class="dl_name_time" title="发表于2013-01-19 15:44:41">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>这个是360投资的</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 15:44:41">1月19日</li>
					<li class="dl_control_from dl_from_address">来自北京市的网友</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502546">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502546, 36994, 1502546, &#39;faceme&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502546, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502546" class="dl_reply">
</div>
	<div id="c1502410" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1823796270">
				<img src="./pwcomments_files/1(1)">
			</a>
			<div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1823796270">叶叶_笙歌</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 15:10:58">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>对楼上这种傻逼说法，所谓急不来，我深深地蛋疼。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 15:10:58">1月19日</li>
					<li class="dl_control_from dl_from_media">来自新浪微博</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502410">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502410, 36994, 1502410, &#39;叶叶_笙歌&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502410, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502410" class="dl_reply">
</div>
	<div id="c1502304" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1669717887">
				<img src="./pwcomments_files/1(2)">
			</a>
			<div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1669717887">撬那僧君很土气</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:04:06">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>知识产权是双刃剑，中国和美国都偏离了一些，不过偏的方向不同罢了。不过鄙视窃取别人劳动成果。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:04:06">1月19日</li>
					<li class="dl_control_from dl_from_media">来自新浪微博</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502304">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502304, 36994, 1502304, &#39;撬那僧君很土气&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502304, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<div class="dl_reply_control">
		<div id="idenglu_showRepliesJS_1502304" class="dl_reply_down" style="display:none">
			<a href="javascript:;" onclick="javascript:_CAC.showReplies(1502304);"><span></span>展开回复</a>
		</div>
		<div id="idenglu_hideRepliesJS_1502304" class="dl_reply_up">
			<a href="javascript:;" onclick="javascript:_CAC.hideReplies(1502304);"><span></span>收起回复</a>
		</div>
	</div>
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502304" class="dl_reply">
	<div id="c1502667" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1669717887">
				<img src="./pwcomments_files/1(2)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1669717887">撬那僧君很土气</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 15:48:03">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>回复@smaverickuma:是说我窃取别人劳动成果么。。。我觉得我快阅读障碍了</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 15:48:03">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502667">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502304, 36994, 1502667, &#39;撬那僧君很土气&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502667, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502668" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1955912680">
				<img src="./pwcomments_files/1(3)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1955912680">smaverickuma</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 15:00:08">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>怎麼連自己也一起鄙視了。。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 15:00:08">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502668">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502304, 36994, 1502668, &#39;smaverickuma&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502668, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
	<div id="c1502300" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/100(1)">
			</a>
			<div class="dl_post_avatar_icon icon_13"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">大狐狸</a>
					<span class="dl_name_icon icon_13"></span>
					<span class="dl_name_from">来自QQ</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:02:47">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>这种流氓恶徒赶紧死掉的好。一点底线都没i有。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:02:47">1月19日</li>
					<li class="dl_control_from dl_from_media">来自QQ</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502300">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502300, 36994, 1502300, &#39;大狐狸&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502300, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502300" class="dl_reply">
</div>
	<div id="c1502273" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1774294331">
				<img src="./pwcomments_files/1(4)">
			</a>
			<div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1774294331">SolidZORO</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:42:49">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>这tools有什么不好的么？如果没有他，我根本不知道ios有多好，更本不知道ios有那么多的可能性。

国人到现在依然还是很难养成购买软件的习惯，哪怕只是一顿饭钱。

而用盗版app和使用正版app是两种心态，自己付费的app肯定会很珍惜，不过这是之后的过程，我认为那些现在用正版的朋友肯定是用过盗版的，绝对绝对用过很长时间的盗版！！

但是这些总会给身边的朋友或者网络上的朋友强调，请支持正版云云。

我说，这需要过程需要时间的好吧，你自己也是这样走过来的，或许成为了app开发者设计师，知道其中之苦了，才领悟到正版的价值，而普通人要悟到正版的重要性可能需要比app开发者更久。

这些tools是过渡，是符合国情的，慢慢来吧，急不来。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:42:49">1月19日</li>
					<li class="dl_control_from dl_from_media">来自新浪微博</li>
					<li class="dl_control_like"><em id="idenglu_vote_1502273">2</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502273, &#39;SolidZORO&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502273, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<div class="dl_reply_control">
		<div id="idenglu_showRepliesJS_1502273" class="dl_reply_down" style="display:none">
			<a href="javascript:;" onclick="javascript:_CAC.showReplies(1502273);"><span></span>展开回复</a>
		</div>
		<div id="idenglu_hideRepliesJS_1502273" class="dl_reply_up">
			<a href="javascript:;" onclick="javascript:_CAC.hideReplies(1502273);"><span></span>收起回复</a>
		</div>
	</div>
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502273" class="dl_reply">
	<div id="c1502281" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/3f54f057876d48d487e64772a35ab5a4">
			</a>
                        
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">匿名</a>
					
					<span class="dl_name_from dl_from_address">来自中国的网友</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:51:37">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>用盗版不是一件可以拿出来大声宣扬并沾沾自喜的事情。“符合国情”，你的思维还真是相当主旋律啊。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:51:37">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502281">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502281, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502281, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502282" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/5645ce7d4bbc2fe1e08d7a1cd8b1c8f1">
			</a>
                        
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">匿名</a>
					
					<span class="dl_name_from dl_from_address">来自北京市的网友</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:52:10">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>这位兄弟评价的中肯。作者的观点就偏激了些，失败者立场。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:52:10">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502282">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502282, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502282, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502283" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1774294331">
				<img src="./pwcomments_files/1(4)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1774294331">SolidZORO</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:47:05">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>回复@好人卡获得者:需要过程！哥！</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:47:05">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502283">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502283, &#39;SolidZORO&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502283, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502284" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1660700675">
				<img src="./pwcomments_files/1(5)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1660700675">1块钱俩内裤</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:46:20">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>坚决鄙视一切盗版行为</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:46:20">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502284">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502284, &#39;1块钱俩内裤&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502284, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502308" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1774994951">
				<img src="./pwcomments_files/1(6)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1774994951">陈粲然SugarRay</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:07:01">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>请看看PC端现状，你就懂了</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:07:01">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502308">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502308, &#39;陈粲然SugarRay&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502308, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502314" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" href="javascript:;">
				<img src="./pwcomments_files/c2308942f3aebb726ba076cba9aaa58f">
			</a>
                        
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" href="javascript:;">匿名</a>
					
					<span class="dl_name_from dl_from_address">来自上海市宝山区的网友</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:14:28">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>小偷强盗偷你东西抢你东西，你追上去骂他，他和你说，这符合国情，这需要过程，你就happy了。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:14:28">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502314">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502314, &#39;匿名&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502314, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502350" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1690149707">
				<img src="./pwcomments_files/1(7)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1690149707">幽灵Jeremy</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:39:58">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>就是素质差，别说那么多借口了。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:39:58">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502350">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502350, &#39;幽灵Jeremy&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502350, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502358" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1708094104">
				<img src="./pwcomments_files/1(8)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1708094104">Philonis高</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:45:45">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>回复@SolidZORO:客观的讲你说的对，只不过人总要有点理想，对吧。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:45:45">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502358">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502358, &#39;Philonis高&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502358, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502359" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1774294331">
				<img src="./pwcomments_files/1(4)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1774294331">SolidZORO</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:11:49">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>回复@Philonis高:这个话题实在太大了，继续纷争下去肯定又要成为战场，我的观点是如果法律规定的情况下，全民正版那正是可喜可贺的事情。不过在没有明确规定下，爱怎么来就怎么来吧，中国人习惯了免费这个硬因素是没办法很快扭转过来的，就如web开发ie6这个硬因素，解决不了就换种方式，剩下的交给时间</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:11:49">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502359">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502359, &#39;SolidZORO&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502359, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502360" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1708094104">
				<img src="./pwcomments_files/1(8)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1708094104">Philonis高</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 13:06:32">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>其实没什么慢慢来的说法。我们做个假设，如果法律没有规定杀人违法，那老百姓们什么时候回慢慢觉得应该约束随意杀人的行为呢？慢慢来一定会走到这一天的，大家都觉得不安全的时候，会自我约束的，但法律为什么还是要一刀切的约束？我们之所以要法律的存在，就是不希望一切有害的东西都是慢慢来解决。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 13:06:32">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502360">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502360, &#39;Philonis高&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502360, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502361" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1660700675">
				<img src="./pwcomments_files/1(5)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1660700675">1块钱俩内裤</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:56:55">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>回复@SolidZORO:5000块买手机，200块程序都可以塞满了都不干。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:56:55">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502361">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502361, &#39;1块钱俩内裤&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502361, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502701" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1458795560">
				<img src="./pwcomments_files/1(9)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1458795560">赁图腾</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 16:36:48">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>我觉得很多东西不需要什么必然的过程，小时候听父母讲当知青下乡，你当时有想过去下乡吗？中国人口众多，90%都穷苦大众，苦了一辈子，累了几十年，如果给你个机会，只要比普通人努力一点，不出2年，你一定可以有钱有权得到自己梦寐以求的生活，但是这个不符合民情，你是觉得你跟随民众苦，还是努力一把过自己想要的生活呢？就算换一个角度来讲，我从2008年开始接触IOS，就一直再itunes上面下载正版的，开始的时候用免费的，我觉得都很全面了，后来免费APP不能满足我了，我开始付费购买APP，IOS5.1.1的时候，我越狱了，但是越狱一个月后，完全不能忍受越狱APP不能立刻享用更新的原因，我唾弃它，我认为，如果连自己想要的正版都购买不了，那么这样的人生可真是失败，自己想要的东西都要换一种流氓的方式去“偸”，自尊心完全接受不了。他尊心就更别说了。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 16:36:48">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502701">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502701, &#39;赁图腾&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502701, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502703" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1458795560">
				<img src="./pwcomments_files/1(9)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1458795560">赁图腾</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 16:38:03">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>没听过一句老话吗？从现在做起，需要什么过程？</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 16:38:03">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502703">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502703, &#39;赁图腾&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502703, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
	<div id="c1502704" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1458795560">
				<img src="./pwcomments_files/1(9)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1458795560">赁图腾</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 16:46:24">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>法律上是有规定不允许转载盗用非法版本，国家不是常年再打击盗版吗？你看那些买盗版的小贩，看到城管为什么跑？并且，在itunes的授权上面就有明确的说明，这样的规章制度只要标出来就形成法律，只是你知道中国的执法人员自己也想用盗版的，所以才没有那么严厉执行。人民敢做，其实是领导的睁一只眼闭一只眼。国人太多，我们没有办法强制要求所有人立刻执行，但是我们能要求自己做到，不要拿别人們做不到来掩饰你也做不到，只要你已经做到不用盗版，不用多解释，只需要告诉我一声：我支持正版，已付出行动；我拒绝盗版，已付出行动。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 16:46:24">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502704">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502273, 36994, 1502704, &#39;赁图腾&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502704, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
	<div id="c1502229" class="dl_post">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1929609404">
				<img src="./pwcomments_files/1(10)">
			</a>
			<div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1929609404">HoloDNG-7</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 11:49:24">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>依然是正版观念的问题啊.</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 11:49:24">1月19日</li>
					<li class="dl_control_from dl_from_media">来自新浪微博</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502229">0</em>人喜欢</li>
				</ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502229, 36994, 1502229, &#39;HoloDNG-7&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502229, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
	<!--展开收起回复列表 begin-->
	<div class="dl_reply_control">
		<div id="idenglu_showRepliesJS_1502229" class="dl_reply_down" style="display:none">
			<a href="javascript:;" onclick="javascript:_CAC.showReplies(1502229);"><span></span>展开回复</a>
		</div>
		<div id="idenglu_hideRepliesJS_1502229" class="dl_reply_up">
			<a href="javascript:;" onclick="javascript:_CAC.hideReplies(1502229);"><span></span>收起回复</a>
		</div>
	</div>
	<!--展开收起回复列表 end-->
</div>
<div id="idenglu_replys_1502229" class="dl_reply">
	<div id="c1502274" class="dl_replay_row">
	<div class="dl_post_main">
		<div class="dl_post_avatar">
			<a rel="nofollow" target="_blank" href="http://weibo.com/1774294331">
				<img src="./pwcomments_files/1(4)">
			</a>
                        <div class="dl_post_avatar_icon icon_3"></div>
		</div>
		<div class="dl_post_body">
			<div class="dl_post_name">
				<div class="dl_name">
					<a class="dl_name_text" rel="nofollow" target="_blank" href="http://weibo.com/1774294331">SolidZORO</a>
					<span class="dl_name_icon icon_3"></span>
					<span class="dl_name_from dl_from_media">来自新浪微博</span>
					<span class="dl_name_time" title="发表于2013-01-19 12:44:09">1月19日</span>
				</div>
			</div>
			<div class="dl_post_content">
				<p>哥们，在这里都能见到你啊。</p>
			</div>
			<div class="dl_post_control layout">
				<ul class="dl_control_message">
					<li class="dl_control_time" title="发表于2013-01-19 12:44:09">1月19日</li>
					<li class="dl_control_like" style="display:none;"><em id="idenglu_vote_1502274">0</em>人喜欢</li>
                                </ul>
				<ul class="dl_post_function">
					<li class="dl_function_reply"><span></span><a onclick="javascript:_CAC.intoReply(1502229, 36994, 1502274, &#39;SolidZORO&#39;);" href="javascript:;">回复</a></li>
					<li class="dl_function_like"><span></span><a onclick="javascript:_CAC.vote(1502274, 36994);" href="javascript:;">喜欢</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
</div>
	</div>
	<!--评论列表 end-->
	<div class="dl_foot">
		<div class="dl_infor layout">
			<div class="dl_infor_message">
			        <div class="dl_message">已有<em>28</em>条评论,共<em>18</em>人参与</div>
				<div class="dl_sort">
					<select class="dl_sort_select">
	<option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=0">按时间排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=1" selected="selected">按时间倒序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=2">按平台排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=3">按好评度排序
	</option><option value="http://open.denglu.cc/connect/comment.jsp?appid=20592denRbLvRNV4o0NRZSqfVtBsXA&amp;postid=5118&amp;domain=www.pingwest.com&amp;from=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F&amp;exit=http%3A%2F%2Fwww.pingwest.com%2Fwp-login.php%3Faction%3Dlogout%26amp%3Bredirect_to%3Dhttp%253A%252F%252Fwww.pingwest.com%252Fwhat-is-chinese-market-the-hell%252F%26amp%3B_wpnonce%3Da5ec8b1a49&amp;sort=4">按回复数排序
</option></select>

				</div>
			</div>
			<div class="dl_infor_page layout"></div>

		</div>
		<div class="dl_foot_powerby"><a href="http://www.denglu.cc/pinglun/" target="_blank">评论框由<em>Denglu</em>提供</a></div>
	</div>
</div>
<!--灯鹭社会化评论 end-->
<!--回复框 -->
<div id="idenglu_reply_div" class="dl_publish_textarea" style="display: none;">
	<div class="dl_avatar"><img src="./pwcomments_files/1"></div>
	<div class="dl_textarea">
		<div class="dl_textarea_input"><textarea id="idenglu_reply_content"></textarea></div>
		<div class="dl_textarea_tool layout">
			<ul class="dl_tool_btn layout">
				<li class="dl_tool_face">
					<a href="javascript:;" onclick="javascript:_CAC.showEmotionModel(event, 3);">表情</a>
					<!--表情弹出层 begin-->
					<div id="idenglu_emotion_3" style="display:none;"></div>
					<!--表情弹出层 end-->
				</li>
				<!--同步部分 begin-->
				<li id="idenglu_synchro_list_3" class="dl_tool_feed">
					<ul class="dl_feed_layout layout">
	<li class="dl_feed_text">同步到：</li>
	<li onclick="javascript:_CAC.clickSynchro(this);" mid="3" ck="0" class="icon_3"></li>
</ul>

				</li>
				<!--同步部分 end-->
			</ul>
			<div class="dl_tool_submit">
				<a class="dl_submit_btn" href="javascript:;" onclick="javascript:_CAC.addReply(36994, 157237, 3);">立即回复</a>
			</div>
		</div>
	</div>
</div>
<!--回复框 end -->
<!-- 表情模块 begin -->
<div style="display: none;" id="idenglu_emotion" class="dl_face_layout">
	<div class="dl_face_head">
		<ul class="dl_face_menu">
	  		<li class="dl_face_default dl_face_click" onclick="javascript:_CAC.selectEmotionTab(event, &#39;qq&#39;, this);">默认</li>
	  		<li class="dl_face_ali" onclick="javascript:_CAC.selectEmotionTab(event, &#39;ali&#39;, this);">阿狸</li>
	  		<li class="dl_face_lang" onclick="javascript:_CAC.selectEmotionTab(event, &#39;lang&#39;, this);">浪小花</li>
		</ul>
	  	<a href="javascript:;" class="dl_face_close" onclick="javascript:_CAC.hideEmotionModel(event);"></a>
	</div>
	<div class="dl_face_body">
		<div class="dl_face_box_qq">
		    <div class="dl_face_icon" id="idenglu_emotion_tab_qq">
				<a title="微笑" href="javascript:;"></a>
				<a title="撇嘴" href="javascript:;"></a>
				<a title="色" href="javascript:;"></a>
				<a title="发呆" href="javascript:;"></a>
				<a title="得意" href="javascript:;"></a>
				<a title="流泪" href="javascript:;"></a>
				<a title="害羞" href="javascript:;"></a>
				<a title="闭嘴" href="javascript:;"></a>
				<a title="睡" href="javascript:;"></a>
				<a title="大哭" href="javascript:;"></a>
				<a title="尴尬" href="javascript:;"></a>
				<a title="发怒" href="javascript:;"></a>
				<a title="调皮" href="javascript:;"></a>
				<a title="呲牙" href="javascript:;"></a>
				<a title="惊讶" href="javascript:;"></a>
				<a title="难过" href="javascript:;"></a>
				<a title="酷" href="javascript:;"></a>
				<a title="冷汗" href="javascript:;"></a>
				<a title="抓狂" href="javascript:;"></a>
				<a title="吐" href="javascript:;"></a>
				<a title="偷笑" href="javascript:;"></a>
				<a title="可爱" href="javascript:;"></a>
				<a title="白眼" href="javascript:;"></a>
				<a title="傲慢" href="javascript:;"></a>
				<a title="饥饿" href="javascript:;"></a>
				<a title="困" href="javascript:;"></a>
				<a title="惊恐" href="javascript:;"></a>
				<a title="流汗" href="javascript:;"></a>
				<a title="憨笑" href="javascript:;"></a>
				<a title="大兵" href="javascript:;"></a>
				<a title="奋斗" href="javascript:;"></a>
				<a title="咒骂" href="javascript:;"></a>
				<a title="疑问" href="javascript:;"></a>
				<a title="嘘" href="javascript:;"></a>
				<a title="晕" href="javascript:;"></a>
				<a title="折磨" href="javascript:;"></a>
				<a title="衰" href="javascript:;"></a>
				<a title="骷髅" href="javascript:;"></a>
				<a title="敲打" href="javascript:;"></a>
				<a title="再见" href="javascript:;"></a>
				<a title="擦汗" href="javascript:;"></a>
				<a title="抠鼻" href="javascript:;"></a>
				<a title="鼓掌" href="javascript:;"></a>
				<a title="糗大了" href="javascript:;"></a>
				<a title="坏笑" href="javascript:;"></a>
				<a title="左哼哼" href="javascript:;"></a>
				<a title="右哼哼" href="javascript:;"></a>
				<a title="哈欠" href="javascript:;"></a>
				<a title="鄙视" href="javascript:;"></a>
				<a title="委屈" href="javascript:;"></a>
				<a title="快哭了" href="javascript:;"></a>
				<a title="阴险" href="javascript:;"></a>
				<a title="亲亲" href="javascript:;"></a>
				<a title="吓" href="javascript:;"></a>
				<a title="可怜" href="javascript:;"></a>
				<a title="菜刀" href="javascript:;"></a>
				<a title="西瓜" href="javascript:;"></a>
				<a title="啤酒" href="javascript:;"></a>
				<a title="篮球" href="javascript:;"></a>
				<a title="乒乓" href="javascript:;"></a>
				<a title="咖啡" href="javascript:;"></a>
				<a title="饭" href="javascript:;"></a>
				<a title="猪头" href="javascript:;"></a>
				<a title="玫瑰" href="javascript:;"></a>
				<a title="凋谢" href="javascript:;"></a>
				<a title="示爱" href="javascript:;"></a>
				<a title="爱心" href="javascript:;"></a>
				<a title="心碎" href="javascript:;"></a>
				<a title="蛋糕" href="javascript:;"></a>
				<a title="闪电" href="javascript:;"></a>
				<a title="炸弹" href="javascript:;"></a>
				<a title="刀" href="javascript:;"></a>
				<a title="足球" href="javascript:;"></a>
				<a title="瓢虫" href="javascript:;"></a>
				<a title="便便" href="javascript:;"></a>
				<a title="月亮" href="javascript:;"></a>
				<a title="太阳" href="javascript:;"></a>
				<a title="礼物" href="javascript:;"></a>
				<a title="拥抱" href="javascript:;"></a>
				<a title="强" href="javascript:;"></a>
				<a title="弱" href="javascript:;"></a>
				<a title="握手" href="javascript:;"></a>
				<a title="胜利" href="javascript:;"></a>
				<a title="抱拳" href="javascript:;"></a>
				<a title="勾引" href="javascript:;"></a>
				<a title="拳头" href="javascript:;"></a>
				<a title="差劲" href="javascript:;"></a>
				<a title="爱你" href="javascript:;"></a>
				<a title="NO" href="javascript:;"></a>
				<a title="OK" href="javascript:;"></a>
				<a title="爱情" href="javascript:;"></a>
				<a title="飞吻" href="javascript:;"></a>
				<a title="跳跳" href="javascript:;"></a>
				<a title="发抖" href="javascript:;"></a>
				<a title="怄火" href="javascript:;"></a>
				<a title="转圈" href="javascript:;"></a>
				<a title="磕头" href="javascript:;"></a>
				<a title="回头" href="javascript:;"></a>
				<a title="跳绳" href="javascript:;"></a>
				<a title="挥手" href="javascript:;"></a>
				<a title="激动" href="javascript:;"></a>
				<a title="街舞" href="javascript:;"></a>
				<a title="献吻" href="javascript:;"></a>
				<a title="左太极" href="javascript:;"></a>
				<a title="右太极" href="javascript:;"></a>
			</div>
		    <div class="dl_face_icon" id="idenglu_emotion_tab_ali" style="display: none;">
				<a title="ali做鬼脸" href="javascript:;"></a>
				<a title="ali追" href="javascript:;"></a>
				<a title="ali转圈哭" href="javascript:;"></a>
				<a title="ali转" href="javascript:;"></a>
				<a title="ali郁闷" href="javascript:;"></a>
				<a title="ali元宝" href="javascript:;"></a>
				<a title="ali摇晃" href="javascript:;"></a>
				<a title="ali嘘嘘嘘" href="javascript:;"></a>
				<a title="ali羞" href="javascript:;"></a>
				<a title="ali笑死了" href="javascript:;"></a>
				<a title="ali笑" href="javascript:;"></a>
				<a title="ali掀桌子" href="javascript:;"></a>
				<a title="ali献花" href="javascript:;"></a>
				<a title="ali想" href="javascript:;"></a>
				<a title="ali吓" href="javascript:;"></a>
				<a title="ali哇" href="javascript:;"></a>
				<a title="ali吐血" href="javascript:;"></a>
				<a title="ali偷看" href="javascript:;"></a>
				<a title="ali送礼物" href="javascript:;"></a>
				<a title="ali睡" href="javascript:;"></a>
				<a title="ali甩手" href="javascript:;"></a>
				<a title="ali摔" href="javascript:;"></a>
				<a title="ali撒钱" href="javascript:;"></a>
				<a title="ali亲一个" href="javascript:;"></a>
				<a title="ali欠揍" href="javascript:;"></a>
				<a title="ali扑倒" href="javascript:;"></a>
				<a title="ali扑" href="javascript:;"></a>
				<a title="ali飘过" href="javascript:;"></a>
				<a title="ali飘" href="javascript:;"></a>
				<a title="ali喷嚏" href="javascript:;"></a>
				<a title="ali拍拍手" href="javascript:;"></a>
				<a title="ali你" href="javascript:;"></a>
				<a title="ali挠墙" href="javascript:;"></a>
				<a title="ali摸摸头" href="javascript:;"></a>
				<a title="ali溜" href="javascript:;"></a>
				<a title="ali赖皮" href="javascript:;"></a>
				<a title="ali来吧" href="javascript:;"></a>
				<a title="ali揪" href="javascript:;"></a>
				<a title="ali囧" href="javascript:;"></a>
				<a title="ali惊" href="javascript:;"></a>
				<a title="ali加油" href="javascript:;"></a>
				<a title="ali僵尸跳" href="javascript:;"></a>
				<a title="ali呼拉圈" href="javascript:;"></a>
				<a title="ali画圈圈" href="javascript:;"></a>
				<a title="ali欢呼" href="javascript:;"></a>
				<a title="ali坏笑" href="javascript:;"></a>
				<a title="ali跪求" href="javascript:;"></a>
				<a title="ali风筝" href="javascript:;"></a>
				<a title="ali飞" href="javascript:;"></a>
				<a title="ali翻白眼" href="javascript:;"></a>
				<a title="ali顶起" href="javascript:;"></a>
				<a title="ali点头" href="javascript:;"></a>
				<a title="ali得瑟" href="javascript:;"></a>
				<a title="ali打篮球" href="javascript:;"></a>
				<a title="ali打滚" href="javascript:;"></a>
				<a title="ali大吃" href="javascript:;"></a>
				<a title="ali踩" href="javascript:;"></a>
				<a title="ali不耐烦" href="javascript:;"></a>
				<a title="ali不嘛" href="javascript:;"></a>
				<a title="ali别吵" href="javascript:;"></a>
				<a title="ali鞭炮" href="javascript:;"></a>
				<a title="ali抱一抱" href="javascript:;"></a>
				<a title="ali拜年" href="javascript:;"></a>
				<a title="ali88" href="javascript:;"></a>
		    </div>
		    <div class="dl_face_icon" id="idenglu_emotion_tab_lang" style="display: none;">
				<a title="转发" href="javascript:;"></a>
				<a title="笑哈哈" href="javascript:;"></a>
				<a title="得意地笑" href="javascript:;"></a>
				<a title="噢耶" href="javascript:;"></a>
				<a title="偷乐" href="javascript:;"></a>
				<a title="泪流满面" href="javascript:;"></a>
				<a title="巨汗" href="javascript:;"></a>
				<a title="抠鼻屎" href="javascript:;"></a>
				<a title="求关注" href="javascript:;"></a>
				<a title="真V5" href="javascript:;"></a>
				<a title="群体围观" href="javascript:;"></a>
				<a title="hold住" href="javascript:;"></a>
				<a title="羞嗒嗒" href="javascript:;"></a>
				<a title="非常汗" href="javascript:;"></a>
				<a title="许愿" href="javascript:;"></a>
				<a title="崩溃" href="javascript:;"></a>
				<a title="好囧" href="javascript:;"></a>
				<a title="震惊" href="javascript:;"></a>
				<a title="别烦我" href="javascript:;"></a>
				<a title="不好意思" href="javascript:;"></a>
				<a title="纠结" href="javascript:;"></a>
				<a title="拍手" href="javascript:;"></a>
				<a title="给劲" href="javascript:;"></a>
				<a title="好喜欢" href="javascript:;"></a>
				<a title="好爱哦" href="javascript:;"></a>
				<a title="路过这儿" href="javascript:;"></a>
				<a title="悲催" href="javascript:;"></a>
				<a title="不想上班" href="javascript:;"></a>
				<a title="躁狂症" href="javascript:;"></a>
				<a title="甩甩手" href="javascript:;"></a>
				<a title="瞧瞧" href="javascript:;"></a>
				<a title="同意" href="javascript:;"></a>
				<a title="喝多了" href="javascript:;"></a>
				<a title="啦啦啦啦" href="javascript:;"></a>
				<a title="杰克逊" href="javascript:;"></a>
				<a title="雷锋" href="javascript:;"></a>
				<a title="传火炬" href="javascript:;"></a>
				<a title="加油啊" href="javascript:;"></a>
				<a title="亲一口" href="javascript:;"></a>
				<a title="放假啦" href="javascript:;"></a>
				<a title="立志青年" href="javascript:;"></a>
				<a title="下班" href="javascript:;"></a>
				<a title="困死了" href="javascript:;"></a>
				<a title="好棒" href="javascript:;"></a>
				<a title="有鸭梨" href="javascript:;"></a>
				<a title="膜拜了" href="javascript:;"></a>
				<a title="互相膜拜" href="javascript:;"></a>
				<a title="拍砖" href="javascript:;"></a>
				<a title="互相拍砖" href="javascript:;"></a>
				<a title="采访" href="javascript:;"></a>
				<a title="发表言论" href="javascript:;"></a>
				<a title="愚人节" href="javascript:;"></a>
				<a title="复活节" href="javascript:;"></a>
				<a title="想一想" href="javascript:;"></a>
				<a title="放电抛媚" href="javascript:;"></a>
				<a title="霹雳" href="javascript:;"></a>
				<a title="被电" href="javascript:;"></a>
				<a title="中箭" href="javascript:;"></a>
				<a title="丘比特" href="javascript:;"></a>
				<a title="牛" href="javascript:;"></a>
				<a title="推荐" href="javascript:;"></a>
				<a title="赞啊" href="javascript:;"></a>
				<a title="招财" href="javascript:;"></a>
				<a title="挤火车" href="javascript:;"></a>
				<a title="赶火车" href="javascript:;"></a>
				<a title="金元宝" href="javascript:;"></a>
				<a title="福到啦" href="javascript:;"></a>
				<a title="红包拿来" href="javascript:;"></a>
				<a title="萌翻" href="javascript:;"></a>
				<a title="收藏" href="javascript:;"></a>
				<a title="拜年了" href="javascript:;"></a>
				<a title="龙啸" href="javascript:;"></a>
				<a title="玫瑰" href="javascript:;"></a>
				<a title="放鞭炮" href="javascript:;"></a>
				<a title="发红包" href="javascript:;"></a>
				<a title="大红灯笼" href="javascript:;"></a>
				<a title="耍花灯" href="javascript:;"></a>
				<a title="吃汤圆" href="javascript:;"></a>
		    </div>
		</div>
	</div>
</div>

<!-- 表情模块 end -->
<!-- 登录模块 begin -->
		<div id="idenglu_login_div" class="dlComments_popup_box" style="display: none;">
		<div class="dlComments_popup_table">
			<div class="dlComments_popup dlComments_popupLogin">
				<div class="dl_community_head">
					<p class="dl_community_title">使用合作账号登录</p>
					<a href="javascript:;" onclick="javascript:_CAC.hideLogin();" class="dl_community_close" id="dlComments_LoginClose"></a>
				</div>
				<div class="dl_community_body">
					<div class="popupLogin_div">
						<ul class="popupLogin_list layout">
						<li title="QQ"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/qzone?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_qzone">使用QQ账号登录</a></li>
						<li title="新浪微博"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/sina?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_sina">使用新浪微博账号登录</a></li>
						<li title="腾讯微博"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tencent?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_tencent">使用腾讯微博账号登录</a></li>
						<li title="人人网"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/renren?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_renren">使用人人网账号登录</a></li>
						<li title="淘宝"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/taobao?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_taobao">使用淘宝账号登录</a></li>
						<li title="支付宝"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/alipayquick?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_alipayquick">使用支付宝账号登录</a></li>
						<li title="豆瓣"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/douban?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_douban">使用豆瓣账号登录</a></li>
						<li title="百度"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/baidu?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_baidu">使用百度账号登录</a></li>
						<li title="开心网"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/kaixin001?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_kaixin001">使用开心网账号登录</a></li>
						<li title="网易微博"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/netease?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_netease">使用网易微博账号登录</a></li>
						<li title="搜狐微博"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/sohu?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_sohu">使用搜狐微博账号登录</a></li>
						<li title="天涯"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tianya?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_tianya">使用天涯账号登录</a></li>
						<li title="MSN"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/windowslive?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_windowslive">使用MSN账号登录</a></li>
						<li title="Google"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/google?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_google">使用Google账号登录</a></li>
						<li title="雅虎"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/yahoo?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_yahoo">使用雅虎账号登录</a></li>
						<li title="网易163"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/netease163?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_netease163">使用网易163账号登录</a></li>
						<li title="360"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/guard360?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_guard360">使用360账号登录</a></li>
						<li title="天翼"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tianyi?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_tianyi">使用天翼账号登录</a></li>
						<li title="Facebook"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/facebook?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_facebook">使用Facebook账号登录</a></li>
						<li title="Twitter"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/twitter?appid=36994&method=comment&redirect_uri=http%3A%2F%2Fwww.pingwest.com%2Fwhat-is-chinese-market-the-hell%2F" class="denglu_30Icon_twitter">使用Twitter账号登录</a></li>
						</ul>
					</div>
				<div class="dlComments_popupEmail">
					<p class="popupEmail_tlt">匿名账号登录</p>
					<div class="popupEmail_emailDiv layout">
						<div class="popupEmail_emailLab">
							<p class="emailLab_username"><label>昵称</label><input id="idenglu_name" type="text"></p>
							<p class="emailLab_email"><label>邮箱</label><input id="idenglu_email" type="text"></p>
							<p class="emailLab_url"><label>网址</label><input id="idenglu_homepage" type="text"></p>
							<p><a href="javascript:;" onclick="javascript:_CAC.strangeLoign(36994);" class="dl_submit_btn" hidefocus="true">登录</a></p>
						</div>
						<p class="popupEmail_emailGrav">支持使用<a target="_blank" href="http://gravatar.com/">Gravatar头像</a></p>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>

<!-- 登录模块 end -->
<!-- 社区中心模块 begin -->

<!-- 社区中心模块 end -->
<!-- 一键分享模块 begin -->
<div class="dlComments_popup_box" id="ndenglu_share" style="display:none;">
    <div class="dlComments_popup_table">
        <div class="dlComments_popup dlComments_popupShare">
            <div class="dl_community_head">
            	<p class="dl_community_title">分享文章到您的微博</p>
                <a href="javascript:;" onclick="javascript:_CAC.hideShare();" class="dl_community_close"></a>
            </div>
            <div class="dl_community_body layout">
            	<div class="dlComments_share layout">
				<p class="dlComments_shareTlt layout">
               	<a class="dlComments_shareH" href="http://www.pingwest.com/what-is-chinese-market-the-hell/" target="_blank">“流氓助手”和它的朋友们</a>
               </p>
				<div class="dlComments_shareCon layout">
					<div class="dlComments_shareImg">
						<img width="180" height="120" src="./pwcomments_files/屏幕快照-2013-01-19-上午8.21.22.png">
					</div>
				</div>
			</div>
			<div class="dlComments_shareTxt">
				<p class="shareTxt_num">已输入&nbsp;&nbsp;<span id="idenglu_share_content_count">0</span>&nbsp;&nbsp;字</p>
				<div class="dl_textarea">
					<div class="dl_textarea_input">
						<textarea id="idenglu_share_content" class="publish_conText shareTxt_conText"></textarea>
					</div>
					<div class="dl_textarea_tool layout">
						<ul class="publish_bottomList">
							<li class="dl_tool_face">
								<a hidefocus="true" class="denglu_emotionBTN" href="javascript:;" onclick="javascript:_CAC.showEmotionModel(event, 2);">表情</a>
                           	<div id="idenglu_emotion_2" class="emotion_list">
                           		<span class="dlComments_popArrow"></span>
                           	</div>
                       	</li>
               		</ul>
					</div>
				</div>
               <div class="shareTxt_div layout">
               	<div class="shareTxt_listH">分享到</div>
                   <div class="shareTxt_listDiv">
                   	<ul id="idenglu_share_synchro" class="shareTxt_list layout">
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/qzone?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_qzone_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>QQ</span><s><a href="http://open.denglu.cc/transfer/qzone?appid=36994&muid=10798774&method=comment" title="绑定QQ" target="_blank">绑定</a></s></p>
							</li>
                       	<li>
                           	<a href="javascript:;" class="denglu_30Icon_sina"></a>
                               <p class="shareTxt_info"><span>新浪微博</span><s><input type="checkbox" checked="checked" value="3" onclick="javascript:_CAA.removeShareMediaSelect(this);"></s></p>
                           </li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/tencent?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_tencent_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>腾讯微博</span><s><a href="http://open.denglu.cc/transfer/tencent?appid=36994&muid=10798774&method=comment" title="绑定腾讯微博" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/renren?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_renren_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>人人网</span><s><a href="http://open.denglu.cc/transfer/renren?appid=36994&muid=10798774&method=comment" title="绑定人人网" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/netease?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_netease_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>网易微博</span><s><a href="http://open.denglu.cc/transfer/netease?appid=36994&muid=10798774&method=comment" title="绑定网易微博" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/sohu?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_sohu_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>搜狐微博</span><s><a href="http://open.denglu.cc/transfer/sohu?appid=36994&muid=10798774&method=comment" title="绑定搜狐微博" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/tianya?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_tianya_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>天涯</span><s><a href="http://open.denglu.cc/transfer/tianya?appid=36994&muid=10798774&method=comment" title="绑定天涯" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/windowslive?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_windowslive_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>MSN</span><s><a href="http://open.denglu.cc/transfer/windowslive?appid=36994&muid=10798774&method=comment" title="绑定MSN" target="_blank">绑定</a></s></p>
							</li>
							<li>
								<a rel="nofollow" href="http://open.denglu.cc/transfer/twitter?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_twitter_bind" target="_blank"></a>
								<p class="shareTxt_info"><span>Twitter</span><s><a href="http://open.denglu.cc/transfer/twitter?appid=36994&muid=10798774&method=comment" title="绑定Twitter" target="_blank">绑定</a></s></p>
							</li>
							</ul>
						</div>
						<p class="shareTxt_state layout">
						</p><p class="shareTxt_stateTlt">您只能分享到已绑定的社交帐号</p>
							<span class="shareTxt_stateInp"><input type="checkbox" checked="checked" onclick="javascript:_CAA.allShareMediaSelect(this);" id="idenglu_share_synchro_select"><label for="idenglu_share_synchro_select">全选</label></span>
							<a hidefocus="true" class="dl_submit_btn" href="javascript:;" onclick="javascript:_CAC.share(36994, 157237);">一键分享</a>
						<p></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- 一键分享模块 end -->
<!-- 绑定登录模块 begin -->
 	<div class="dlComments_popup_box" id="idenglu_bind_div" style="display:none;">
		<div class="dlComments_popup_table">
			<div class="dlComments_popup w380">
				<div class="dl_community_head">
				  	<p class="dl_community_title">绑定登录和同步帐号</p>
				  	<a href="javascript:;" onclick="javascript:_CAC.hideBind();" class="dl_community_close"></a>
				</div>
               <div class="dl_community_body layout">
					<div class="popupLogin_div">
						<ul class="popupLogin_list w320 layout">
					  		<li title="QQ新浪微博"><a target="_blank" href="javascript:;" onclick="javascript:_CAC.unbind(36994, 10798774);" class="denglu_30Icon_sina" title="已绑定新浪微博账号">已绑定新浪微博账号</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/qzone?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_qzone_bind" title="使用QQ账号登录">使用QQ账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tencent?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_tencent_bind" title="使用腾讯微博账号登录">使用腾讯微博账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/renren?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_renren_bind" title="使用人人网账号登录">使用人人网账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/netease?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_netease_bind" title="使用网易微博账号登录">使用网易微博账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/sohu?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_sohu_bind" title="使用搜狐微博账号登录">使用搜狐微博账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tianya?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_tianya_bind" title="使用天涯账号登录">使用天涯账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/windowslive?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_windowslive_bind" title="使用MSN账号登录">使用MSN账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/twitter?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_twitter_bind" title="使用Twitter账号登录">使用Twitter账号登录</a></li>
						</ul>
					</div>
					<div class="dl_community_head_more">
				  		<p class="dl_community_title">绑定更多登陆帐号</p>
					</div>
					<div class="popupLogin_div">
						<ul class="popupLogin_list w320 layout">
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/taobao?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_taobao_bind" title="使用淘宝账号登录">使用淘宝账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/alipayquick?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_alipayquick_bind" title="使用支付宝账号登录">使用支付宝账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/douban?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_douban_bind" title="使用豆瓣账号登录">使用豆瓣账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/baidu?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_baidu_bind" title="使用百度账号登录">使用百度账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/kaixin001?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_kaixin001_bind" title="使用开心网账号登录">使用开心网账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/google?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_google_bind" title="使用Google账号登录">使用Google账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/yahoo?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_yahoo_bind" title="使用雅虎账号登录">使用雅虎账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/netease163?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_netease163_bind" title="使用网易163账号登录">使用网易163账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/guard360?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_guard360_bind" title="使用360账号登录">使用360账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/tianyi?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_tianyi_bind" title="使用天翼账号登录">使用天翼账号登录</a></li>
					  		<li title="QQ空间"><a rel="nofollow" target="_blank" href="http://open.denglu.cc/transfer/facebook?appid=36994&muid=10798774&method=comment" class="denglu_30Icon_facebook_bind" title="使用Facebook账号登录">使用Facebook账号登录</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	 </div>

<!-- 绑定登录模块 end -->
</div>
<script type="text/javascript">
$(function() {
	// content cookie
	var commentContent = $.cookie(commentCookieName);
	var shareContent = $.cookie(shareCookieName);
	if (commentContent) {
		$("#idenglu_comment_content").val("" + commentContent).keyup();
	}
	if (shareContent) {
		$("#idenglu_share_content").val("" + shareContent).keyup();
	}
	idenglu_resize_();
});
var _idenglu_resize_time = 0;
function idenglu_resize_() {
	if (_idenglu_resize_time < 10) {
		resizeIframeComment();
		setTimeout(function() {idenglu_resize_();}, _idenglu_resize_time++);	
	}
}
</script>

</body></html>