<?php 

echo stripslashes(get_option('uyan_src'));

?>

