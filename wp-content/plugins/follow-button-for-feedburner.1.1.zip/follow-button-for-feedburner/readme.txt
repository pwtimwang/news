=== Follow Button for FeedBurner ===
Contributors: TheAdityaJain
Tags: Follow, Follow Button for FeedBurner, Subscribe, Subscribe Button, Follow Button for Wordpress.org users, Aditya, Aditya Jain, Follow button for non Wordpress.com users, FeedBurner, Follow Button for FeedBurner using sites/blog
Requires at least: 3.0
Tested up to: 3.3.1
Plugin Version: 1.1
Stable Tag: 1.1

Adds a floating Follow Button to FeedBurner using WP sites. Use Follow Plugin if your don't use FeedBurner.

== Description ==

This plugin collects inserts a Follow Button on the bottom right corner of your website (the follow button which appears on every wordpress.com blog) and uses it to collect email address and passes them to your FeedBurner Email Subscription Database.

Thatmeans you can use your existing FeedBurner Account to send email updates to your subscribers.

<strong>NOTE: This plugin requires FeedBurner Email Subscription Service to be activated</strong>

If you do not use FeedBurner you can download the "Follow" Plugin instead. Follow Plugin is listed in the Wordpress plugin repository at http://wordpress.org/extended/plugins/follow

Tweet <a href="http://twitter.com/TheAdityaJain">@TheAdityaJain</a> or visit <a href="http://forum.adityajain.name">My Community Discussion Forum at http://forum.adityajain.name</a> if you require some tutorial any further help, queries, problems & hacks.

Visit <a href="http://www.mywp.in">www.mywp.in</a> for tutorials, tips & tricks and hacks.

== Installation ==

1. Install and Activate the "Follow Button For FeedBurner" Plugin
2. Goto WordPress DashBoard>>>Settings>>>Follow for FeedBurner and enter your FeedBurner Feeds ID and Save.

To activate Email Subscription Service for your feedburner feed, Login to your FeedBurner account >> Click on the Feed of your website >> Click Publicize >> Email Subscription and click activate. See Screenshot for illustration.

Visit <a href="http://www.mywp.in">www.mywp.in</a> for tutorials, tips & tricks and hacks.

== Frequently Asked Questions ==

= 1. What does this plugin do? =
This plugin adds a floating follow button to your blog/website, the same follow button which appears every on WP.COM blogs to collect email address and passes them to FeedBurner Email Subscription Service of your FeedBurner Feed.

= 2. Why Follow Button =
Well, the answer is very simple. I and many of the Wordpress.org users(may be you too) are jealous of the follow button that appears on 
right bottom of all wordpress.com users. And I think why Wordpress.org users must be deprived from it.Thats It! 

= 3. Will it have any other sideeffect on my blog or slow down it? =
No

For any more Questions Tweet <a href="http://twitter.com/TheAdityaJain">@TheAdityaJain</a> 

== Screenshots ==

1. Activating Email Subscription Service for your FeedBurner Feed.

== Changelog ==

= 1.1 = 
Removes the One and Only Bug - Now the plugin is perfect to use
= 1.0 =
Initial Release